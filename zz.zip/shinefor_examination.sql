-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 08, 2024 at 01:05 PM
-- Server version: 5.7.44-cll-lve
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shinefor_examination`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_acc`
--

CREATE TABLE `admin_acc` (
  `admin_id` int(11) NOT NULL,
  `temail` varchar(1000) NOT NULL,
  `tpassword` varchar(1000) NOT NULL,
  `tname` varchar(100) NOT NULL,
  `tdob` varchar(100) NOT NULL,
  `tgender` varchar(100) NOT NULL,
  `reset_token` varchar(255) NOT NULL,
  `reset_token_expiry` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tstatus` varchar(100) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_acc`
--

INSERT INTO `admin_acc` (`admin_id`, `temail`, `tpassword`, `tname`, `tdob`, `tgender`, `reset_token`, `reset_token_expiry`, `tstatus`) VALUES
(1, 'admin@shineforteinternationalschool.com.ng', 'admin@paswd', 'Administrator', '', '', '9801', '2023-08-17 00:41:47', 'Active'),
(2, 'olatunjikenny694@gmail.com', 'Mobile@1234', 'test', '2023-06-12', 'male', '', '2023-08-16 17:46:07', 'Active'),
(3, 'cjohnson@shineforteinternationalschool.com', 'password', 'Johnson Chinonyerem Anamemena Grace ', '1988-08-28', 'female', '', '2023-08-16 15:42:03', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `course_tbl`
--

CREATE TABLE `course_tbl` (
  `cou_id` int(11) NOT NULL,
  `cou_name` varchar(1000) NOT NULL,
  `cou_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_tbl`
--

INSERT INTO `course_tbl` (`cou_id`, `cou_name`, `cou_created`) VALUES
(101, 'JSS1', '2023-08-09 12:53:03'),
(102, 'JSS2', '2023-08-09 12:53:39'),
(103, 'JSS3', '2023-08-09 12:54:05'),
(104, 'SS1', '2023-08-09 12:54:29'),
(105, 'SS2', '2023-08-09 12:54:54'),
(106, 'SS3', '2023-08-09 12:55:20'),
(107, 'ENTRANCE EXAM', '2023-08-09 12:55:57');

-- --------------------------------------------------------

--
-- Table structure for table `examinee_tbl`
--

CREATE TABLE `examinee_tbl` (
  `exmne_id` int(11) NOT NULL,
  `exmne_fullname` varchar(1000) NOT NULL,
  `exmne_course` varchar(1000) NOT NULL,
  `exmne_gender` varchar(1000) NOT NULL,
  `exmne_birthdate` varchar(1000) NOT NULL,
  `exmne_email` varchar(1000) NOT NULL,
  `exmne_password` varchar(1000) NOT NULL,
  `exmne_status` varchar(1000) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `examinee_tbl`
--

INSERT INTO `examinee_tbl` (`exmne_id`, `exmne_fullname`, `exmne_course`, `exmne_gender`, `exmne_birthdate`, `exmne_email`, `exmne_password`, `exmne_status`) VALUES
(1, 'Dorcas Oyewole', '107', 'female', '1995-08-10', 'SIS/OO1/2020', '23456', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `exam_answers`
--

CREATE TABLE `exam_answers` (
  `exans_id` int(11) NOT NULL,
  `axmne_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `quest_id` int(11) NOT NULL,
  `exans_answer` varchar(1000) NOT NULL,
  `exans_status` varchar(1000) NOT NULL DEFAULT 'new',
  `exans_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_answers`
--

INSERT INTO `exam_answers` (`exans_id`, `axmne_id`, `exam_id`, `quest_id`, `exans_answer`, `exans_status`, `exans_created`) VALUES
(1, 1, 33, 10, ' recieve', 'new', '2023-08-09 13:58:10'),
(2, 1, 33, 1, 'A person, place, or thing', 'new', '2023-08-09 13:58:10'),
(3, 1, 33, 2, 'London', 'new', '2023-08-09 13:58:10'),
(4, 1, 33, 7, 'Have you finished your homework?', 'new', '2023-08-09 13:58:10'),
(5, 1, 33, 14, 'Did you finish your homework?', 'new', '2023-08-09 13:58:10'),
(6, 1, 33, 12, 'Kind and giving', 'new', '2023-08-09 13:58:10'),
(7, 1, 33, 9, 'The most important point', 'new', '2023-08-09 13:58:10'),
(8, 1, 33, 3, 'happy', 'new', '2023-08-09 13:58:11'),
(9, 1, 33, 8, 'and', 'new', '2023-08-09 13:58:11'),
(10, 1, 33, 11, 'The mouse was chased by the cat.', 'new', '2023-08-09 13:58:11'),
(11, 1, 33, 5, 'Adverb', 'new', '2023-08-09 13:58:11'),
(12, 1, 33, 6, ' They visited the museum last week.', 'new', '2023-08-09 13:58:11'),
(13, 1, 33, 13, 'Her smile was as bright as the sun.', 'new', '2023-08-09 13:58:11');

-- --------------------------------------------------------

--
-- Table structure for table `exam_attempt`
--

CREATE TABLE `exam_attempt` (
  `examat_id` int(11) NOT NULL,
  `exmne_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `examat_status` varchar(1000) NOT NULL DEFAULT 'used'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_attempt`
--

INSERT INTO `exam_attempt` (`examat_id`, `exmne_id`, `exam_id`, `examat_status`) VALUES
(1, 1, 33, 'used');

-- --------------------------------------------------------

--
-- Table structure for table `exam_question_tbl`
--

CREATE TABLE `exam_question_tbl` (
  `eqt_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `exam_question` varchar(1000) NOT NULL,
  `exam_ch1` varchar(1000) NOT NULL,
  `exam_ch2` varchar(1000) NOT NULL,
  `exam_ch3` varchar(1000) NOT NULL,
  `exam_ch4` varchar(1000) NOT NULL,
  `exam_answer` varchar(1000) NOT NULL,
  `exam_status` varchar(1000) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_question_tbl`
--

INSERT INTO `exam_question_tbl` (`eqt_id`, `exam_id`, `exam_question`, `exam_ch1`, `exam_ch2`, `exam_ch3`, `exam_ch4`, `exam_answer`, `exam_status`) VALUES
(1, 33, 'What is the correct definition of a noun?', 'A person, place, or thing', ' A describing word', 'An action word', 'A feeling or emotion', 'A person, place, or thing', 'active'),
(2, 33, 'Which of the following is an example of a proper noun?', 'book', 'teacher', 'school', 'London', 'London', 'active'),
(3, 33, 'Choose the synonym for \"joyful\":', 'sad', 'happy', 'angry', 'scared', 'happy', 'active'),
(5, 33, 'What part of speech is the word \"quickly\" in the sentence: \"She ran quickly to catch the bus.\"', ' Noun', 'Adjective', 'Adverb', 'Verb', 'Adverb', 'active'),
(6, 33, 'Which sentence is in the past tense?', 'He will go to the park tomorrow.', 'She is reading a book now.', 'They are playing soccer after school.', ' They visited the museum last week.', 'They visited the museum last week.', 'active'),
(7, 33, 'Which of the following sentences is a question?', 'The sun shines brightly in the sky.', 'I love eating ice cream.', 'Have you finished your homework?', 'They played soccer all afternoon.', 'Have you finished your homework?', 'active'),
(8, 33, 'Which word is a conjunction?', 'run', 'and', 'blue', 'jump', ' and', 'active'),
(9, 33, 'What is the main idea of a paragraph?', 'The last sentence', 'The longest sentence', 'The sentence with the most difficult words', 'The most important point', 'The most important point', 'active'),
(10, 33, 'Choose the correct spelling:', ' recieve', 'recieve', ' receive', ' recive', ' receive', 'active'),
(11, 33, 'Which of the following sentences is in passive voice?', 'The cat chased the mouse.', 'The mouse was chased by the cat.', 'The mouse was chasing the cat.', 'The cat and mouse play together.', 'The mouse was chased by the cat.', 'active'),
(12, 33, ' What is the meaning of the word \"generous\"?', 'Angry', 'Kind and giving', 'Sad', 'Tired', 'Kind and giving', 'active'),
(13, 33, 'Which of the following is an example of a simile?', 'The wind whispered through the trees.', 'Her smile was as bright as the sun.', 'The ocean waves danced on the shore.', 'The mountain stood tall and majestic.', 'Her smile was as bright as the sun.', 'active'),
(14, 33, 'Identify the correct punctuation for this sentence: Did you finish your homework', ' Did you finish your homework.', 'Did you finish your homework?', 'Did you finish your homework!', 'Did you finish your homework?', 'Did you finish your homework?', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `exam_tbl`
--

CREATE TABLE `exam_tbl` (
  `ex_id` int(11) NOT NULL,
  `cou_id` int(11) NOT NULL,
  `ex_title` varchar(1000) NOT NULL,
  `ex_time_limit` varchar(1000) NOT NULL,
  `ex_questlimit_display` int(11) NOT NULL,
  `ex_description` varchar(1000) NOT NULL,
  `ex_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_tbl`
--

INSERT INTO `exam_tbl` (`ex_id`, `cou_id`, `ex_title`, `ex_time_limit`, `ex_questlimit_display`, `ex_description`, `ex_created`) VALUES
(33, 107, 'ENGLISH LANGUAGE', '20', 15, 'Answer all the following questions correctly', '2023-08-09 12:58:21');

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks_tbl`
--

CREATE TABLE `feedbacks_tbl` (
  `fb_id` int(11) NOT NULL,
  `exmne_id` int(11) NOT NULL,
  `fb_exmne_as` varchar(1000) NOT NULL,
  `fb_feedbacks` varchar(1000) NOT NULL,
  `fb_date` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `tid` int(100) NOT NULL,
  `temail` varchar(100) NOT NULL,
  `tname` varchar(100) NOT NULL,
  `tdob` date NOT NULL,
  `tgender` varchar(100) NOT NULL,
  `tpassword` varchar(100) NOT NULL,
  `reset_token` varchar(255) NOT NULL,
  `reset_token_expiry` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tstatus` varchar(100) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`tid`, `temail`, `tname`, `tdob`, `tgender`, `tpassword`, `reset_token`, `reset_token_expiry`, `tstatus`) VALUES
(0, 'Kehinde@ictinschool.ng', 'oyedele kehinde', '2023-08-03', 'male', 'Mobile@1234', 'b747', '2023-08-17 00:31:21', 'active'),
(0, 'olatunjikenny694@gmail.com', 'olatunji kehinde', '2019-04-13', 'male', 'Mobile@1234', '', '2023-08-16 17:29:54', 'active'),
(0, 'test3@gmail.com', 'test3', '2023-06-06', 'male', '1234567890', '', '2023-08-16 15:43:39', 'active'),
(0, 'test@gmail.com', 'test2', '2023-05-13', 'male', '1234567890', '', '2023-08-16 15:43:39', 'active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_acc`
--
ALTER TABLE `admin_acc`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `course_tbl`
--
ALTER TABLE `course_tbl`
  ADD PRIMARY KEY (`cou_id`);

--
-- Indexes for table `examinee_tbl`
--
ALTER TABLE `examinee_tbl`
  ADD PRIMARY KEY (`exmne_id`);

--
-- Indexes for table `exam_answers`
--
ALTER TABLE `exam_answers`
  ADD PRIMARY KEY (`exans_id`);

--
-- Indexes for table `exam_attempt`
--
ALTER TABLE `exam_attempt`
  ADD PRIMARY KEY (`examat_id`);

--
-- Indexes for table `exam_question_tbl`
--
ALTER TABLE `exam_question_tbl`
  ADD PRIMARY KEY (`eqt_id`);

--
-- Indexes for table `exam_tbl`
--
ALTER TABLE `exam_tbl`
  ADD PRIMARY KEY (`ex_id`);

--
-- Indexes for table `feedbacks_tbl`
--
ALTER TABLE `feedbacks_tbl`
  ADD PRIMARY KEY (`fb_id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`temail`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_acc`
--
ALTER TABLE `admin_acc`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `course_tbl`
--
ALTER TABLE `course_tbl`
  MODIFY `cou_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT for table `examinee_tbl`
--
ALTER TABLE `examinee_tbl`
  MODIFY `exmne_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `exam_answers`
--
ALTER TABLE `exam_answers`
  MODIFY `exans_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `exam_attempt`
--
ALTER TABLE `exam_attempt`
  MODIFY `examat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `exam_question_tbl`
--
ALTER TABLE `exam_question_tbl`
  MODIFY `eqt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `exam_tbl`
--
ALTER TABLE `exam_tbl`
  MODIFY `ex_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `feedbacks_tbl`
--
ALTER TABLE `feedbacks_tbl`
  MODIFY `fb_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
