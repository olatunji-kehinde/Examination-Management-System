 Created Password

admin
Username: admin@username
Password: admin@password

user
Username:SHF001
Password:1234567890
