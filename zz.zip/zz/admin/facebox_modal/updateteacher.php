
<?php 
  include("../../conn.php");
  $id = $_GET['id'];
 
  $selExmne = $conn->query("SELECT * FROM admin_acc WHERE admin_id='$id' ")->fetch(PDO::FETCH_ASSOC);

 ?>

<fieldset style="width:543px;" >
	<legend><i class="facebox-header"><i class="edit large icon"></i>&nbsp;Update <b>( <?php echo strtoupper($selExmne['tname']); ?> )</b></i></legend>
  <div class="col-md-12 mt-4">
<form method="post" id="updateExamineeFrm1">
     <div class="form-group">
        <legend>Fullname</legend>
        <input type="hidden" name="tname" value="<?php echo $id; ?>">
        <input type="" name="tname" class="form-control" required="" value="<?php echo $selExmne['tname']; ?>" >
     </div>

     <div class="form-group">
        <legend>Gender</legend>
        <select class="form-control" name="tgender">
          <option value="<?php echo $selExmne['tgender']; ?>"><?php echo $selExmne['tgender']; ?></option>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>
     </div>

     <div class="form-group">
        <legend>Birthdate</legend>
        <input type="date" name="tdob" class="form-control" required="" value="<?php echo date('Y-m-d',strtotime($selExmne["tdob"])) ?>"/>
     </div>

     

    

     <div class="form-group">
        <legend>Email</legend>
        <input type="email" name="temail" class="form-control" required="" value="<?php echo $selExmne['temail']; ?>" >
     </div>

     <div class="form-group">
        <legend>Password</legend>
        <input type="password" name="tpassword" class="form-control" required="" value="<?php echo $selExmne['tpassword']; ?>" >
     </div>

     <div class="form-group">
        <legend>Status</legend>
        <input type="hidden" name="tstatus" value="<?php echo $id; ?>">
        <input type="" name="tstatus" class="form-control" required="" value="<?php echo $selExmne['tstatus']; ?>" >
     </div>
  <div class="form-group" align="right">
    <button type="submit" class="btn btn-sm btn-primary">Update Now</button>
  </div>
</form>
  </div>
</fieldset>







