<?php
 include("../../conn.php");
 extract($_POST);


$updCourse = $conn->query("UPDATE teacher SET tname='$tname',  tgender='$tgender', tdob='$tdob', temail='$temail', tpassword='$tpassword' WHERE temail='$temail' ");
if($updCourse)
{
	   $res = array("res" => "success", "exFullname" => $tname);
}
else
{
	   $res = array("res" => "failed");
}



 echo json_encode($res);	
?>