<?php 

$host = "www.shineforteinternationalschool.com.ng";
$user = "shinefor_shineforte";
$pass = "Mobile@1234";
$db   = "shinefor_examination";
$conn = null;

try {
  $conn = new PDO("mysql:host={$host};dbname={$db};",$user,$pass);
} catch (Exception $e) {
  
}


 ?>