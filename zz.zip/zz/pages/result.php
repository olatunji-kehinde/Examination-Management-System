 <?php 
    $examId = $_GET['id'];
    $selExam = $conn->query("SELECT * FROM exam_tbl WHERE ex_id='$examId' ")->fetch(PDO::FETCH_ASSOC);

 ?>

<div class="app-main__outer">
<div class="app-main__inner">
    <div id="refreshData">
            
    <div class="col-md-12">
        <div class="app-page-title">
            <div class="page-title-wrapper">
                <div class="page-title-heading">
                    <div>
                        <?php echo $selExam['ex_title']; ?>
                          <div class="page-title-subheading">
                            <?php echo $selExam['ex_description']; ?>
                          </div>

                    </div>
                </div>
            </div>
        </div>  
        <div class="row col-md-12">
        	<h2 class="text-info">RESULT</h2>
        </div>

        <div class="row col-md-6 float-left">
        	<div class="main-card mb-3 card">
                <div class="card-body">
                	<h5 class="card-title"></h5>
                    <h6><b>Thanks for Participating in the Exam. We wish you best of luck. The school will get to you when your result is ready</b></h6>
        			
                </div>
            </div>
        </div>
    

        <div class="row col-md-12">
        	<h2 class="text-danger">FEEDBACK</h2>
        </div>

        <div class="row col-md-6 float-left">
        	<div class="main-card mb-3 card">
                <div class="card-body">
                	<h5 class="card-title"></h5>
                    <h6><b>If you have any issue during the exam, you can use the feedback button to send us your complaints. Thanks</b></h6>
        			
                </div>
            </div>
        </div>

      

           
            </div>
        </div>
    </div>


    </div>
</div>
