<?php 
 include("../../conn.php");


extract($_POST);

$selname = $conn->query("SELECT * FROM admin_acc WHERE tname='$tname' ");
$selEmail = $conn->query("SELECT * FROM admin_acc WHERE temail='$temail' ");


if($tgender == "0")
{
	$res = array("res" => "noGender");
}
else if($tdob == "0")
{
	$res = array("res" => "noDob");
}

else if($selname->rowCount() > 0)
{
	$res = array("res" => "fullnameExist", "msg" => $tname);
}
else if($selEmail->rowCount() > 0)
{
	$res = array("res" => "emailExist", "msg" => $temail);
}
else
{
	$insData = $conn->query("INSERT INTO admin_acc(tname,tdob,tgender,temail,tpassword) VALUES('$tname','$tdob','$tgender','$temail','$tpassword')  ");
	if($insData)
	{
		$res = array("res" => "success", "msg" => $temail);
	}
	else
	{
		$res = array("res" => "failed");
	}
}


echo json_encode($res);
 ?>