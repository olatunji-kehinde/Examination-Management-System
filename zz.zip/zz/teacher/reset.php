<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db_host = "www.shineforteinternationalschool.com.ng";
    $db_username = "shinefor_shineforte";
    $db_password ="Mobile@1234";
    $db_name = "shinefor_examination";

    // Create a database connection
    $conn = new mysqli($db_host, $db_username, $db_password, $db_name);

    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    $email = isset($_POST['email']) ? $conn->real_escape_string($_POST['email']) : '';

    // Check if the user exists in the database
    $sql = "SELECT * FROM teacher WHERE temail = '$email'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        // Generate a random reset token
        $resetToken = bin2hex(random_bytes(2));

        
        // Calculate token expiration time (e.g., 1 hour from now)
        $resetTokenExpiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

        // Update the user's reset token and token expiry in the database
        $updateSql = "UPDATE teacher SET reset_token = '$resetToken', reset_token_expiry = '$resetTokenExpiry' WHERE temail = '$email'";
        if ($conn->query($updateSql)) {
            // In a real application, you would send an email with the reset link,
            // which includes the token as a URL parameter
            $to ="$email";
            $subject = "PASSWORD RESET";
            $header = "From: noreply@shineforteintenationalschool.com.ng";
            $message = "$resetToken";
            mail($to,$subject,$message,$header);
            
            header("Location: verifytoken.php");
        
        } else {
           echo "Error ";
        }
    } else {
        http_response_code(404);
        echo "User not found";
    }

   

    $conn->close();
}
?>