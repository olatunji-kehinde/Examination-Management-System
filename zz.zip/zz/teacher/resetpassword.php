<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $db_host = "www.shineforteinternationalschool.com.ng";
    $db_username = "shinefor_shineforte";
    $db_password ="Mobile@1234";
    $db_name = "shinefor_examination";

    // Create a database connection
    $conn = new mysqli($db_host, $db_username, $db_password, $db_name);

    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    $resetToken = isset($_POST['token']) ? $conn->real_escape_string($_POST['token']) : '';
    $newPassword = isset($_POST['pass']) ? $_POST['pass'] : '';

    // Check if the reset token is valid and has not expired
    $sql = "SELECT * FROM teacher WHERE reset_token = '$resetToken' AND reset_token_expiry >= NOW()";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
       // $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

        // Update the user's password and reset token in the database
        $updateSql = "UPDATE teacher SET tpassword = '$newPassword', reset_token = NULL, reset_token_expiry = NULL WHERE reset_token = '$resetToken'";
        if ($conn->query($updateSql)) {
           header("Location: index.php");
        } else {
            $response = ['message' => 'An error occurred.'];
        }
    } else {
        http_response_code(400);
        $response = ['message' => 'Invalid reset token or token has expired.'];
    }

    echo json_encode($response);

    $conn->close();
}
?>